#include<process_copy.h>

void p_wait(void)
{

	while(wait(NULL) != -1);
}
